﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Palindrome.App
{
    public static class Palindro
    {
        public static bool CheckPalindrome(string text)
        {
            string string1, rev;
            string1 = text;
            char[] ch = string1.ToCharArray();
            Array.Reverse(ch);
            rev = new string(ch);
            bool result = string1.Equals(rev, StringComparison.OrdinalIgnoreCase);

            return result;
        }
    }
}
