using Microsoft.VisualStudio.TestTools.UnitTesting;
using Palindrome.App;

namespace Palindrome.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void IsPalindrome()
        {
            //Arrange
            string text = "Rotator";
   
            //Act
            var result = Palindro.CheckPalindrome(text);

            // Assert
            Assert.IsTrue(result);
        }
    }
}
